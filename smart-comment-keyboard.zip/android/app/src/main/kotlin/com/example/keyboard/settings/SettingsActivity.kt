package com.example.keyboard.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.keyboard.databinding.ActivitySettingsBinding
import android.content.Context
import android.content.SharedPreferences

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("keyboard_prefs", Context.MODE_PRIVATE)

        loadSettings()

        binding.saveButton.setOnClickListener {
            saveSettings()
            finish()
        }
    }

    private fun loadSettings() {
        val apiKey = sharedPreferences.getString("api_key", "")
        val aiMode = sharedPreferences.getBoolean("ai_mode", false)
        
        binding.apiKeyInput.setText(apiKey)
        binding.aiModeSwitch.isChecked = aiMode
    }

    private fun saveSettings() {
        val apiKey = binding.apiKeyInput.text.toString()
        val aiMode = binding.aiModeSwitch.isChecked
        
        sharedPreferences.edit().apply {
            putString("api_key", apiKey)
            putBoolean("ai_mode", aiMode)
            apply()
        }
    }
}
