package com.example.keyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import com.example.keyboard.data.CommentDatabase
import com.example.keyboard.data.CommentEntity
import kotlinx.coroutines.*
import java.util.*

class SmartKeyboardService : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var qwertyKeyboard: Keyboard
    private lateinit var suggestionStrip: LinearLayout
    private lateinit var categoryBar: LinearLayout
    
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var database: CommentDatabase

    override fun onCreate() {
        super.onCreate()
        database = CommentDatabase.getDatabase(this)
    }

    override fun onCreateInputView(): View {
        val root = layoutInflater.inflate(R.layout.keyboard_view, null)
        
        keyboardView = root.findViewById(R.id.keyboard_view)
        qwertyKeyboard = Keyboard(this, R.xml.qwerty)
        keyboardView.keyboard = qwertyKeyboard
        keyboardView.setOnKeyboardActionListener(this)

        suggestionStrip = root.findViewById(R.id.suggestion_strip)
        categoryBar = root.findViewById(R.id.category_bar)

        setupCategoryBar()
        updateSuggestions("")

        return root
    }

    private fun setupCategoryBar() {
        val categories = listOf("Morning", "Afternoon", "Night", "Custom")
        categories.forEach { category ->
            val button = Button(this).apply {
                text = category
                setOnClickListener { showCommentsForCategory(category) }
            }
            categoryBar.addView(button)
        }
    }

    private fun showCommentsForCategory(category: String) {
        scope.launch {
            val comments = withContext(Dispatchers.IO) {
                database.commentDao().getCommentsByCategory(category)
            }
            // Update suggestion strip with comments
            updateSuggestionStrip(comments)
        }
    }

    private fun updateSuggestionStrip(comments: List<CommentEntity>) {
        suggestionStrip.removeAllViews()
        comments.forEach { comment ->
            val button = Button(this).apply {
                text = comment.text
                setOnClickListener { insertComment(comment) }
            }
            suggestionStrip.addView(button)
        }
    }

    private fun insertComment(comment: CommentEntity) {
        scope.launch {
            val variations = withContext(Dispatchers.IO) {
                database.commentDao().getVariationsForComment(comment.id)
            }
            
            val textToInsert = if (variations.isNotEmpty()) {
                variations.random().text
            } else {
                comment.text + (comment.emoji ?: "")
            }
            
            currentInputConnection.commitText(textToInsert, 1)
        }
    }

    private fun updateSuggestions(query: String) {
        // Implement prefix matching logic here
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic = currentInputConnection ?: return
        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> ic.deleteSurroundingText(1, 0)
            Keyboard.KEYCODE_SHIFT -> { /* Handle shift */ }
            Keyboard.KEYCODE_DONE -> ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
            else -> {
                val code = primaryCode.toChar()
                ic.commitText(code.toString(), 1)
            }
        }
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
