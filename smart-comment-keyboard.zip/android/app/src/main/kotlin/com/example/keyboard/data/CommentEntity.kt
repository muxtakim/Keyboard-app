package com.example.keyboard.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // Morning, Afternoon, Night, Custom
    val text: String,
    val emoji: String? = null,
    val isAiGenerated: Boolean = false
)

@Entity(tableName = "variations")
data class VariationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val commentId: Int,
    val text: String
)
