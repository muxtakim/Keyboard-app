package com.example.keyboard.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CommentDao {
    @Query("SELECT * FROM comments WHERE category = :category")
    fun getCommentsByCategory(category: String): Flow<List<CommentEntity>>

    @Query("SELECT * FROM variations WHERE commentId = :commentId")
    suspend fun getVariationsForComment(commentId: Int): List<VariationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVariation(variation: VariationEntity)

    @Delete
    suspend fun deleteComment(comment: CommentEntity)

    @Query("DELETE FROM comments")
    suspend fun clearAll()
}
