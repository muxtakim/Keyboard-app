# Smart Comment Keyboard (Android)

This is a production-ready Android keyboard application built with Kotlin and Android Studio.

## Features
- **Gboard-like UI/UX**: Top suggestion bar, category buttons, and QWERTY layout.
- **Smart Comment Groups**: Predefined categories for Morning, Afternoon, Night, and Custom comments.
- **Anti-Spam Variation Engine**: Randomly selects variations for comments to avoid social media spam filters.
- **AI Integration**: Optional AI mode using Gemini to generate unique comment variations.
- **Local Storage**: Uses Room Database to store comments and variations.
- **Settings Screen**: Manage API keys, toggle AI mode, and customize comments.

## How to Build the APK

1. **Open in Android Studio**:
   - Import the `android` folder as a new project in Android Studio.
   - Wait for Gradle sync to complete.

2. **Configure API Key**:
   - Go to the Settings screen in the app.
   - Enter your Gemini API key (get one from [Google AI Studio](https://aistudio.google.com/)).
   - Toggle "AI Mode" to ON.

3. **Build APK**:
   - Go to `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   - Once the build is complete, the APK will be located in `app/build/outputs/apk/debug/`.

4. **Install on Device**:
   - Transfer the APK to your Android device.
   - Enable "Install from Unknown Sources" in your device settings.
   - Install and enable the keyboard in `Settings > Languages & Input > On-screen keyboard`.

## Tech Stack
- **Kotlin**: Primary programming language.
- **InputMethodService**: Android API for custom keyboards.
- **Room Database**: Local data persistence.
- **Material Design 3**: Modern UI components.
- **Coroutines**: Asynchronous tasks and API calls.
- **Retrofit**: (Optional) For AI API integration.

## License
Apache-2.0
