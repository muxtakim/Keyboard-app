import { CommentGroup } from './types';

export const DEFAULT_GROUPS: CommentGroup[] = [
  {
    id: 'morning',
    name: 'Morning',
    comments: [
      { id: 'm1', text: 'Good morning', emoji: '☀️' },
      { id: 'm2', text: 'শুভ সকাল', emoji: '😊' },
      { id: 'm3', text: 'সুপ্রভাত', emoji: '🌸' },
      { id: 'm4', text: 'Rise and shine!', emoji: '✨' },
    ],
  },
  {
    id: 'afternoon',
    name: 'Afternoon',
    comments: [
      { id: 'a1', text: 'Good afternoon', emoji: '☕' },
      { id: 'a2', text: 'শুভ অপরাহ্ন', emoji: '🌞' },
      { id: 'a3', text: 'Hope you are having a great day', emoji: '🌈' },
    ],
  },
  {
    id: 'night',
    name: 'Night',
    comments: [
      { id: 'n1', text: 'Good night', emoji: '🌙' },
      { id: 'n2', text: 'শুভ রাত্রি', emoji: '😴' },
      { id: 'n3', text: 'Sweet dreams', emoji: '⭐' },
    ],
  },
  {
    id: 'custom',
    name: 'Custom',
    comments: [
      { id: 'c1', text: 'Great post!', emoji: '🔥' },
      { id: 'c2', text: 'Love this!', emoji: '❤️' },
      { id: 'c3', text: 'Amazing content', emoji: '🙌' },
    ],
  },
];
