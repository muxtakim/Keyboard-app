import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Settings, 
  ChevronLeft, 
  ChevronRight, 
  Search, 
  Sparkles, 
  Clock, 
  Sun, 
  Moon, 
  Coffee, 
  Plus,
  Trash2,
  Check,
  X
} from 'lucide-react';
import { cn } from '../lib/utils';
import { CommentGroup, CommentVariation, AppSettings } from '../types';
import { DEFAULT_GROUPS } from '../constants';
import { generateCommentVariations } from '../services/aiService';

interface KeyboardSimulatorProps {
  onOpenSettings: () => void;
  settings: AppSettings;
}

const QWERTY_LAYOUT = [
  ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
  ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
  ['z', 'x', 'c', 'v', 'b', 'n', 'm', '⌫'],
  ['?123', '🌐', 'space', '↵']
];

export default function KeyboardSimulator({ onOpenSettings, settings }: KeyboardSimulatorProps) {
  const [inputText, setInputText] = useState('');
  const [activeGroup, setActiveGroup] = useState<CommentGroup | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [groups, setGroups] = useState<CommentGroup[]>(DEFAULT_GROUPS);

  const [toast, setToast] = useState<string | null>(null);

  // Update time for time-based suggestions
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  // Time-based suggestion logic
  const getTimeBasedSuggestion = () => {
    const hour = currentTime.getHours();
    if (hour >= 5 && hour < 12) return 'Morning';
    if (hour >= 12 && hour < 17) return 'Afternoon';
    return 'Night';
  };

  // Handle key press
  const handleKeyPress = (key: string) => {
    if (key === '⌫') {
      setInputText(prev => prev.slice(0, -1));
    } else if (key === 'space') {
      setInputText(prev => prev + ' ');
    } else if (key === '↵') {
      setInputText(prev => prev + '\n');
    } else if (key === '?123' || key === '🌐') {
      // Not implemented in simulator
    } else {
      setInputText(prev => prev + key);
    }
  };

  // Handle comment selection
  const handleCommentSelect = async (comment: CommentVariation) => {
    let textToInsert = comment.text;
    if (comment.emoji) textToInsert += ` ${comment.emoji}`;

    if (settings.aiMode) {
      setIsGenerating(true);
      try {
        const variations = await generateCommentVariations(comment.text, settings.apiKey);
        if (variations.length > 0) {
          // Randomly select one
          textToInsert = variations[Math.floor(Math.random() * variations.length)];
        }
      } catch (error) {
        console.error("AI Generation failed:", error);
      } finally {
        setIsGenerating(false);
      }
    }

    // Simulate "One-tap paste" by copying to clipboard and showing toast
    try {
      await navigator.clipboard.writeText(textToInsert);
      setToast(`Copied: "${textToInsert}"`);
      setTimeout(() => setToast(null), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }

    setInputText(prev => prev + textToInsert);
    setActiveGroup(null);
  };

  // Prefix matching for suggestions
  useEffect(() => {
    if (inputText.length > 0) {
      const lastWord = inputText.split(' ').pop()?.toLowerCase() || '';
      if (lastWord.length > 1) {
        const matches = groups.flatMap(g => g.comments)
          .filter(c => c.text.toLowerCase().startsWith(lastWord))
          .map(c => c.text)
          .slice(0, 3);
        setSuggestions(matches);
      } else {
        setSuggestions([]);
      }
    } else {
      setSuggestions([]);
    }
  }, [inputText, groups]);

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 overflow-hidden">
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 20, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-slate-800 dark:bg-slate-100 text-white dark:text-slate-900 rounded-full text-xs font-bold shadow-xl flex items-center gap-2"
          >
            <Check className="w-3 h-3 text-green-400" />
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
      {/* Input Area (Simulator) */}
      <div className="flex-1 p-4 flex flex-col">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Simulator Input</span>
          <button 
            onClick={() => setInputText('')}
            className="text-xs text-blue-500 hover:text-blue-600 font-medium"
          >
            Clear
          </button>
        </div>
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Type something or use the keyboard below..."
          className="w-full flex-1 p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 resize-none text-lg"
        />
      </div>

      {/* Keyboard Container */}
      <div className="bg-slate-100 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 p-1 pb-safe shadow-2xl">
        
        {/* Suggestion Strip */}
        <div className="h-12 flex items-center px-2 gap-2 overflow-x-auto no-scrollbar border-b border-slate-200/50 dark:border-slate-800/50">
          {isGenerating ? (
            <div className="flex items-center gap-2 px-3 text-blue-500 animate-pulse">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-medium">Generating AI variations...</span>
            </div>
          ) : suggestions.length > 0 ? (
            suggestions.map((s, i) => (
              <button
                key={i}
                onClick={() => {
                  const words = inputText.split(' ');
                  words.pop();
                  setInputText(words.join(' ') + (words.length > 0 ? ' ' : '') + s + ' ');
                }}
                className="px-4 py-1.5 bg-white dark:bg-slate-800 rounded-full text-sm font-medium shadow-sm border border-slate-200 dark:border-slate-700 whitespace-nowrap"
              >
                {s}
              </button>
            ))
          ) : (
            <div className="flex items-center gap-2 px-2 text-slate-400">
              <Clock className="w-4 h-4" />
              <span className="text-sm">Suggested: {getTimeBasedSuggestion()}</span>
            </div>
          )}
        </div>

        {/* Category Bar */}
        <div className="h-14 flex items-center px-1 gap-1 overflow-x-auto no-scrollbar">
          <button 
            onClick={onOpenSettings}
            className="p-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
          >
            <Settings className="w-5 h-5" />
          </button>
          
          <div className="w-px h-6 bg-slate-300 dark:bg-slate-700 mx-1" />

          {groups.map(group => (
            <button
              key={group.id}
              onClick={() => setActiveGroup(activeGroup?.id === group.id ? null : group)}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 whitespace-nowrap",
                activeGroup?.id === group.id 
                  ? "bg-blue-500 text-white shadow-lg shadow-blue-500/30 scale-105" 
                  : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              )}
            >
              {group.id === 'morning' && <Sun className="w-4 h-4" />}
              {group.id === 'afternoon' && <Coffee className="w-4 h-4" />}
              {group.id === 'night' && <Moon className="w-4 h-4" />}
              {group.id === 'custom' && <Plus className="w-4 h-4" />}
              {group.name}
            </button>
          ))}
        </div>

        {/* Comment List (Overlay) */}
        <AnimatePresence>
          {activeGroup && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden bg-white dark:bg-slate-800 rounded-t-2xl mx-1 mb-1"
            >
              <div className="p-2 grid grid-cols-2 gap-2">
                {activeGroup.comments.map(comment => (
                  <button
                    key={comment.id}
                    onClick={() => handleCommentSelect(comment)}
                    className="p-3 text-left bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:border-blue-200 transition-all group"
                  >
                    <div className="text-sm font-medium text-slate-700 dark:text-slate-200 line-clamp-1">
                      {comment.text}
                    </div>
                    {comment.emoji && (
                      <div className="text-lg mt-1">{comment.emoji}</div>
                    )}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* QWERTY Layout */}
        <div className="flex flex-col gap-1.5 p-1">
          {QWERTY_LAYOUT.map((row, rowIndex) => (
            <div key={rowIndex} className="flex justify-center gap-1.5">
              {row.map((key, keyIndex) => {
                const isSpecial = ['⌫', 'space', '↵', '?123', '🌐'].includes(key);
                return (
                  <button
                    key={keyIndex}
                    onClick={() => handleKeyPress(key)}
                    className={cn(
                      "h-12 rounded-lg flex items-center justify-center font-medium transition-all active:scale-95 active:bg-slate-300 dark:active:bg-slate-600",
                      key === 'space' ? "flex-[5] bg-white dark:bg-slate-800 shadow-sm" :
                      key === '⌫' || key === '↵' ? "flex-[1.5] bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-200" :
                      isSpecial ? "flex-1 bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-200" :
                      "flex-1 bg-white dark:bg-slate-800 shadow-sm text-slate-800 dark:text-slate-100 uppercase text-lg"
                    )}
                  >
                    {key === 'space' ? '' : key}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
