import React, { useState } from 'react';
import { 
  X, 
  Key, 
  Sparkles, 
  Trash2, 
  Plus, 
  Save,
  Moon,
  Sun,
  Info,
  Github
} from 'lucide-react';
import { cn } from '../lib/utils';
import { AppSettings } from '../types';

interface SettingsPanelProps {
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
}

export default function SettingsPanel({ onClose, settings, onUpdateSettings }: SettingsPanelProps) {
  const [apiKey, setApiKey] = useState(settings.apiKey);
  const [aiMode, setAiMode] = useState(settings.aiMode);
  const [theme, setTheme] = useState(settings.theme);

  const handleSave = () => {
    onUpdateSettings({
      apiKey,
      aiMode,
      theme
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50">
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-500" />
            Keyboard Settings
          </h2>
          <button 
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8 max-h-[70vh] overflow-y-auto">
          
          {/* AI Mode Section */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-xl">
                  <Sparkles className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-800 dark:text-slate-100">AI Mode</h3>
                  <p className="text-xs text-slate-500">Generate smart variations using Gemini</p>
                </div>
              </div>
              <button 
                onClick={() => setAiMode(!aiMode)}
                className={cn(
                  "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none",
                  aiMode ? "bg-blue-500" : "bg-slate-300 dark:bg-slate-700"
                )}
              >
                <span className={cn(
                  "inline-block h-4 w-4 transform rounded-full bg-white transition-transform",
                  aiMode ? "translate-x-6" : "translate-x-1"
                )} />
              </button>
            </div>

            {aiMode && (
              <div className="space-y-2 animate-in slide-in-from-top-2 duration-200">
                <label className="text-xs font-medium text-slate-500 uppercase tracking-wider flex items-center gap-1">
                  <Key className="w-3 h-3" />
                  Gemini API Key
                </label>
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your API key..."
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:outline-none text-sm"
                />
                <p className="text-[10px] text-slate-400 italic">
                  * Key is stored locally and never shared.
                </p>
              </div>
            )}
          </section>

          {/* Theme Section */}
          <section className="space-y-4">
            <h3 className="text-xs font-medium text-slate-500 uppercase tracking-wider">Appearance</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setTheme('light')}
                className={cn(
                  "flex items-center justify-center gap-2 p-3 rounded-xl border-2 transition-all",
                  theme === 'light' 
                    ? "border-blue-500 bg-blue-50 text-blue-700" 
                    : "border-slate-100 dark:border-slate-800 text-slate-500"
                )}
              >
                <Sun className="w-4 h-4" />
                <span className="text-sm font-medium">Light</span>
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={cn(
                  "flex items-center justify-center gap-2 p-3 rounded-xl border-2 transition-all",
                  theme === 'dark' 
                    ? "border-blue-500 bg-blue-900/20 text-blue-400" 
                    : "border-slate-100 dark:border-slate-800 text-slate-500"
                )}
              >
                <Moon className="w-4 h-4" />
                <span className="text-sm font-medium">Dark</span>
              </button>
            </div>
          </section>

          {/* Data Management */}
          <section className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-medium text-slate-500 uppercase tracking-wider">Data Management</h3>
            <div className="space-y-2">
              <button className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group">
                <div className="flex items-center gap-3">
                  <Plus className="w-5 h-5 text-slate-400 group-hover:text-blue-500" />
                  <span className="text-sm text-slate-700 dark:text-slate-300">Add Custom Comments</span>
                </div>
              </button>
              <button 
                onClick={() => {
                  if (confirm("Are you sure you want to clear all data?")) {
                    localStorage.clear();
                    window.location.reload();
                  }
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <Trash2 className="w-5 h-5 text-slate-400 group-hover:text-red-500" />
                  <span className="text-sm text-slate-700 dark:text-slate-300">Clear All Data</span>
                </div>
              </button>
            </div>
          </section>

          {/* About */}
          <section className="pt-4 flex flex-col items-center gap-2 text-slate-400">
            <div className="flex items-center gap-4">
              <Info className="w-4 h-4" />
              <span className="text-xs">Version 1.0.0 (Beta)</span>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="p-6 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-100 dark:border-slate-800 flex gap-3">
          <button 
            onClick={onClose}
            className="flex-1 px-4 py-3 rounded-xl font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            className="flex-1 px-4 py-3 rounded-xl font-semibold bg-blue-500 text-white shadow-lg shadow-blue-500/30 hover:bg-blue-600 transition-all flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

// Helper component for the header
function Settings({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
  );
}
