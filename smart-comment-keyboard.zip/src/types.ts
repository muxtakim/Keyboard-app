export interface CommentVariation {
  id: string;
  text: string;
  emoji?: string;
}

export interface CommentGroup {
  id: string;
  name: string;
  comments: CommentVariation[];
}

export interface AppSettings {
  apiKey: string;
  aiMode: boolean;
  theme: 'light' | 'dark';
}
