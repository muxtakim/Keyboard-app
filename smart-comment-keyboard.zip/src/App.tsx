import React, { useState, useEffect } from 'react';
import KeyboardSimulator from './components/KeyboardSimulator';
import SettingsPanel from './components/SettingsPanel';
import { AppSettings } from './types';

export default function App() {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('keyboard_settings');
    return saved ? JSON.parse(saved) : {
      apiKey: '',
      aiMode: false,
      theme: 'light'
    };
  });

  useEffect(() => {
    localStorage.setItem('keyboard_settings', JSON.stringify(settings));
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  return (
    <div className="h-screen w-full flex flex-col bg-white dark:bg-slate-950 transition-colors duration-300">
      {/* App Header (Simulator Branding) */}
      <header className="px-6 py-4 border-b border-slate-100 dark:border-slate-900 flex items-center justify-between bg-white dark:bg-slate-950 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-500 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <svg 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="white" 
              strokeWidth="2.5" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-6 h-6"
            >
              <rect x="2" y="4" width="20" height="16" rx="2" />
              <path d="M6 8h.01" />
              <path d="M10 8h.01" />
              <path d="M14 8h.01" />
              <path d="M18 8h.01" />
              <path d="M8 12h.01" />
              <path d="M12 12h.01" />
              <path d="M16 12h.01" />
              <path d="M7 16h10" />
            </svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-800 dark:text-slate-100 leading-tight">Smart Keyboard</h1>
            <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">Android Simulator</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <div className={settings.aiMode ? "px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg text-[10px] font-bold uppercase tracking-wider" : "hidden"}>
            AI Active
          </div>
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-xs font-medium text-slate-400">Online</span>
        </div>
      </header>

      {/* Main Simulator Content */}
      <main className="flex-1 relative overflow-hidden">
        <KeyboardSimulator 
          onOpenSettings={() => setIsSettingsOpen(true)} 
          settings={settings}
        />
        
        {isSettingsOpen && (
          <SettingsPanel 
            settings={settings}
            onClose={() => setIsSettingsOpen(false)}
            onUpdateSettings={setSettings}
          />
        )}
      </main>

      {/* Simulator Footer */}
      <footer className="px-6 py-3 border-t border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-950 text-center">
        <p className="text-[10px] text-slate-400 font-medium">
          &copy; 2026 Smart Comment Keyboard • Built for Social Media Marketing
        </p>
      </footer>
    </div>
  );
}

