import { GoogleGenAI, Type } from "@google/genai";

export async function generateCommentVariations(prompt: string, apiKey?: string) {
  const key = apiKey || process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error("Gemini API key is missing");
  }

  const ai = new GoogleGenAI({ apiKey: key });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate 5 short, natural-sounding social media comment variations for the following input: "${prompt}". 
    Include relevant emojis. Return as a JSON array of strings.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.STRING,
        },
      },
    },
  });

  try {
    const text = response.text;
    if (!text) return [];
    return JSON.parse(text) as string[];
  } catch (error) {
    console.error("Failed to parse AI response:", error);
    return [];
  }
}
